import React,{useState,useEffect} from "react";
import { Link } from "react-router-dom";
import axios from 'axios'

export default function CourseList(){

    const [courseList, setCourseList] = useState([])

    useEffect(()=>{
        getCourseLi()
    },[])

    const getCourseLi = async()=>{
        const {data} = await axios.get('http://karka.academy/api/action.php?request=getCourses')
        setCourseList(data.data)
    }
    return(
        <div className="list-section">
            <table className="table table-striped">
                <thead>
                    <tr>
                        <th>Courses</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {courseList.map(item=><li className="list-left pb-3" key={item.id}><Link to={`/course/${item.id}`}>{item.name}</Link></li>)}
                        </td>
                    </tr>
                </tbody>
            </table>

        </div>
    )
}