import { Link } from "react-router-dom"
import '../../src/App.css'
import { useNavigate } from "react-router-dom";


export default function Header({setIsLogged}){

    let navigate = useNavigate()

    const chkLogOut =() =>{
        localStorage.removeItem("login")
        setIsLogged(false)
        navigate('/')
    }
    return(
        <>
            <div className="nav-fix">
                <nav className="navbar navbar-expand-lg navbar-light bg-dark">
                    <div className="container">
                        <h3>
                            <Link to="/home" className="nav-link text-white">Karka academy</Link>
                        </h3>
                        <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                            <span className="navbar-toggler-icon"></span>
                        </button>
                        <div className="navbar-collapse mx-1" id="navbarText">
                            <ul className="navbar-nav me-auto">
                            <li className="nav-item active">
                                <Link to="/home" className="nav-link text-white">Home</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/courses" className="nav-link text-white">Course</Link>
                            </li>
                            </ul>
                            <div>
                            <button type="button" className="btn btn-primary btn-border" onClick={()=>chkLogOut()}>Logout</button>
                            </div>
                            <span className="navbar-text">
                                
                            </span>
                            
                        </div>
                    </div>
                    
                </nav>
            </div>
            
        </>
    )
}