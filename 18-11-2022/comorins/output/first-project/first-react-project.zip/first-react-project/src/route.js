import React,{useState} from 'react'
import {
    BrowserRouter as Router,
    Routes,
    Route
} from 'react-router-dom'
import Home from './pages/Home'
import Login from './pages/Login'
import CourseDetails from './pages/CourseDetails'
import CourseLists from './pages/CourseList'
import Register from './pages/Register'
import UserContext from './pages/store/UserContext'
import CreateCourse from './pages/CreateCourse'


export default function MainRouter(){
  const [isLogged, setIsLogged] = useState(false)
  let login = localStorage.getItem("login")

    return(
        <UserContext.Provider value={{isLogged,setIsLogged}}>
            <Router>
                <Routes>
                    <Route path='/' exact element={!login ? <Login /> : <Home />}/>
                    <Route path='/home' element={<Home />}/>
                    <Route path='/course/:id' element={<CourseDetails />}/>
                    <Route path='/courses' element={<CourseLists />}/>
                    <Route path='/register' element={<Register />} />
                    <Route path='/createCourse' element={<CreateCourse />} />
                </Routes>
            </Router>
        </UserContext.Provider>
       
    )
}