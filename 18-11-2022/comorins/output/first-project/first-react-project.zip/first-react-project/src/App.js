import logo from './logo.svg';
import './App.css';
import MainRouter from './route'
import {useState} from 'react'

function App() {
  return (
    <div className="App">
     <MainRouter />
    </div>
  );
}

export default App;
