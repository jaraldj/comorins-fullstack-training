import Header from "../components/header"
import { useNavigate, useParams } from "react-router-dom"
import axios from "axios"
import { useState, useEffect, useContext } from "react"
import CourseList from "../components/courseList"
import UserContext from "./store/UserContext"

export default function CourseDetails(){
    const value = useContext(UserContext);
    const {isLogged,setIsLogged} = value;
    const params = useParams()
    const navigate = useNavigate()
    const [courseDetails, setCourserDetails] = useState({})

    useEffect(()=>{
        if(!isLogged) navigate('/')
        getCourseDetails()
    },[params.id,isLogged])

    const getCourseDetails = async()=>{
        const {data} = await axios.get(`http://karka.academy/api/action.php?request=getCourseDetails&id=${params.id}`)
        setCourserDetails(data.data)
        // console.log(courseDetails);
    }
    return (
        <>
            <Header setIsLogged={setIsLogged}/>
            <div className="top-marg row">
                <div className="col-4">
                    <CourseList />
                </div>

                <div className="col-8 pt-5">
                    <div className="card-body">
                        <h5 className="card-title">Course Name: {courseDetails.name}</h5>
                        <h6 className="card-subtitle mb-2 text-muted">Price: {courseDetails.price}</h6>
                        <p className="card-text">Desc: {courseDetails.description}</p>
                        <a href="#" className="card-link link-a">Video: {courseDetails.video_id}</a>
                    </div>
                </div>
            </div>
            {/* <h1>Course Name : {courseDetails.description}</h1>
            <h3>Course Price : {courseDetails.video_id}</h3> */}
        </>
    )
}