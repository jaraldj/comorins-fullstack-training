import Header from "../components/header"
import CourseList from "../components/courseList"
import UserContext from "./store/UserContext"
import { useContext } from "react"

export default function CourseLists(){
    const value = useContext(UserContext);
    const {isLogged,setIsLogged} = value;
    return (
        <>
            <Header setIsLogged={setIsLogged}/>
            <h1>This is CourseList</h1>
            <CourseList />
        </>
    )
}