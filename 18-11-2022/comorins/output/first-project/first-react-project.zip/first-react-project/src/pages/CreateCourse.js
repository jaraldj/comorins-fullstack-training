import axios from "axios"
import { useState } from "react"
import 'bootstrap/dist/css/bootstrap.min.css';
import { useNavigate } from "react-router";




export default function CreateCourse(){
    const[createCourse,setCreateCourse]=useState({
        request : 'create_course',
        name : '',
        video_id : '',
        description : '',
        price : '',

    })

    let navigate=useNavigate()
    const create_Course=async()=>{
        const {data}=await axios.post(`http://karka.academy/api/action.php`,JSON.stringify(createCourse))
        console.log(data)
        if(data.status=='success'){
            navigate('/courses')
        }

    }
    return(
        <div>
             <div className='pt-4 pb-4'>
            <h3 className='text-center'>Create Course</h3>
            <form>
                <div className="form-group">
                    <label ><b>Name</b></label>
                    <input type="text" className="form-control" id="formGroupExampleInput"  placeholder="Course Name"  onChange={(e)=>setCreateCourse({...createCourse,name:e.target.value})}/>
                </div>
                <div className="form-group">
                    <label><b>Vedio id</b></label>
                    <input type="text" className="form-control" id="formGroupExampleInput2" placeholder="vedio" onChange={(e)=>setCreateCourse({...createCourse,video_id:e.target.value})}/>
                </div>
                <div className="form-group">
                    <label><b>Pescription</b></label>
                    <input type="text" className="form-control" id="formGroupExampleInput2" placeholder="description" onChange={(e)=>setCreateCourse({...createCourse,description:e.target.value})}/>
                </div>
                <div className="form-group">
                    <label><b>Price</b></label>
                    <input type="text" className="form-control" id="formGroupExampleInput2" placeholder="price" onChange={(e)=>setCreateCourse({...createCourse,price:e.target.value})}/>
                </div>
                <button  type='button' className='btn' onClick={create_Course}>Create</button>
               
            </form>
            
        </div>
        </div>
    )
}