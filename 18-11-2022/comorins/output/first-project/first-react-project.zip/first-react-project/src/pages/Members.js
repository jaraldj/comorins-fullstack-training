import React,{useEffect, useState} from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css'



export default function Members(){

    useEffect(()=>{
        getMembers()
    },[])
    const [Members,setMembers]=useState()
    const getMembers= async()=>{
        const {data}=await axios.get(`http://karka.academy/api/action.php?request=getAllMembers`)
        console.log(data.data)
        setMembers(data.data)
    }
    return(
        <div>
            <h3>Members</h3>
            {Members && Members.map((value,index)=>{
                return(
                    <div key={index}>
                        <p>{value.name}</p>
                    </div>
                )
                
            })}
            
        </div>
    )
}