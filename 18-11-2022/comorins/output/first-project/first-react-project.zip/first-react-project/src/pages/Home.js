import Header from "../components/header"
import React,{useEffect, useContext} from "react"
import { useNavigate } from "react-router-dom";
import CourseList from "../components/courseList";
import UserContext from "./store/UserContext";
import Members from "./Members";

export default function Home(){
    let navigate = useNavigate()
    const value = useContext(UserContext);
    const {isLogged,setIsLogged} = value;
    
    useEffect(()=>{
        if(!isLogged)
            navigate('/')
        },[isLogged])
    return (
        <>
            <Header setIsLogged={setIsLogged}/>
            <div className="row top-marg">
                <div className="col-4">
                    <CourseList />
                </div>
                <div className="col-4">
                    <Members />
                </div>
                <div className="col-2 mt-5">
                    <button onClick={()=>{navigate('/createCourse')}}>Create Course</button>
                </div>
            </div>

        </>
    )
}