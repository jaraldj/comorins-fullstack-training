import './App.css';
import React,{useState} from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

import AddTask from './component/AddTask';
import Update from './component/Update'
import ToDo from './component/ToDo';

function App() {

  const [toDo, setToDo] = useState([]);

  const [newTask, setNewTask] = useState('');
  const [updateData, setUpdateData] = useState('');

  // Add task
  const addTask = () =>{
    if(newTask){
      let num = toDo.length + 1;
      let newEntry = {id : num, title : newTask, status : false}
      setToDo([...toDo, newEntry]);
      setNewTask('')
    }
    
  }

  // Delete Task
  const deleteTask = (id) =>{
    let newTasks = toDo.filter( task => task.id !== id)
    setToDo(newTasks)
  }
  // Mark done
  const markDone = (id) =>{
    let newTaskk = toDo.map(task =>{
      if(task.id === id){
        return ({...task, status: !task.status})
      }
      return task
    })
    setToDo(newTaskk)
  }

  // Cancel update
  const cancelUpdate = () =>{
    setUpdateData('')
  }
  // Change task
  const changeTask = (e) =>{
    let newEntryy = {
      id :updateData.id,
      title : e.target.value,
      status : updateData.status ? true : false
    }
    setUpdateData(newEntryy)
  }
  
  // update task
  const updateTask = () =>{
    let filterRec = [...toDo].filter(task => task.id !== updateData.id);
    let updateObj = [...filterRec, updateData];
    setToDo(updateObj);
    setUpdateData('')
  }

  return (
    <div className="container App">

      <h2>To Do List</h2>
      <br />

      {updateData && updateData ? (
        <Update 
        updateData={updateData} 
        changeTask={changeTask} 
        updateTask={updateTask} 
        cancelUpdate={cancelUpdate}
        />
      ) : (
       <AddTask
        newTask= {newTask}
        addTask={addTask}
        setNewTask ={setNewTask}
       />
      )}
      

   

      {toDo && toDo.length ? '' : 'No Tasks'}

      <ToDo 
      toDo={toDo} 
      markDone={markDone} 
      setUpdateData={setUpdateData} 
      deleteTask={deleteTask}
      />
    </div>
  );
}

export default App;
