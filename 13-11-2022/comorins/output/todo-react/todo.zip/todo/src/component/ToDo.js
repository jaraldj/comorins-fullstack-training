import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import {faTrash, faCircleCheck, faPen} from '@fortawesome/free-solid-svg-icons';

export default function ToDo({toDo, markDone, setUpdateData, deleteTask}){
    return (
        <>
            {toDo && toDo.sort((a,b)=>a.id > b.id ? 1 : -1).map((task, index)=>{
                return (
                <div key={task.id}>
                    <div className='col taskBg'>
                    <div className={ task.status ? 'done' : '' }>
                        <span className='taskNumber'>{index + 1}</span>
                        <span className='taskText'>{task.title}</span>
                    </div>
                    <div className='iconsWrap'>
                        <span onClick={() => markDone(task.id)}>
                        <FontAwesomeIcon icon={faCircleCheck} />
                        </span>
        
                        {task.status ? null : (
                        <span onClick={()=>setUpdateData({
                            id : task.id,
                            title : task.title,
                            status : task.status ? true : false
                        })}>
                            <FontAwesomeIcon icon={faPen} />
                        </span>
                        )}
                        
                        <span onClick={()=>deleteTask(task.id)}>
                        <FontAwesomeIcon icon={faTrash} />
                        </span>
                    </div>
                    </div>
                    
                </div>
                )
            })}
          </>
    );
}