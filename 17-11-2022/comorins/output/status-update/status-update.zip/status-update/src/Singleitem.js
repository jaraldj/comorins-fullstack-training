import React from 'react'

export default function Singleitem({statusBlock, statusKey, statusDelete}){
    return (
        <div>
            <p>{statusBlock}</p>
            <div>
                <button type="button" onClick={() => statusDelete(statusKey)}>Delete</button>
            </div>
        </div>
    )
}