import React from "react";
import Singleitem from './Singleitem'

export default function StatusLi({messages, statusDelete}){
    return(
        <div className="status-li">
             { messages.length < 1 ? (
                <p className="alert-info">
                    No status updates available!
                </p>
      ) : null }

      {
        messages.map((status,index)=>(
            <Singleitem 
                statusBlock = {status}
                key = {index}
                statusKey={ index }
                statusDelete={ statusDelete }
            />
        ))
      }
        </div>
    )
}