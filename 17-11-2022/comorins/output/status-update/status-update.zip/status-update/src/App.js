import './App.css';
import Poststatus from './Poststatus'
import React, {Component} from 'react'
import StatusLi from './StatusLi'

export default class App extends Component {
  constructor(props){
    super(props)

    this.state={
      postUpdateText : "",
      messages : []
    }
  }

  _submitStatus = (e) => {
    e.preventDefault()
    if(this.state.postUpdateText.trim()){
      let newStatus = [this.state.postUpdateText, ...this.state.messages]
      this.setState ({
        postUpdateText : "",
        messages : newStatus
      })
    }
  }
    

  _statusOnChange = (e) =>{
    this.setState({
      postUpdateText : e.target.value
    })
  }

  _statusDelete=(statusKey)=>{
    let copyMsg = [...this.state.messages]
    copyMsg.splice(statusKey, 1)
    this.setState({
      messages : copyMsg
    })
  }

  render(){
    // console.log(this.state.postUpdateText);
    console.log(this.state.messages);

    return (
      <div className="App">
        <h3>Status Update</h3>
        <Poststatus 
        submitStatus={this._submitStatus}
        statusValue = {this.state.postUpdateText}
        statusOnChange = {this._statusOnChange}
        />
        <StatusLi 
        messages = {this.state.messages}
        statusDelete = {this._statusDelete}
        />

      </div>
    );
  } 
}

