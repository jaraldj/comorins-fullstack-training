export default function Poststatus({submitStatus, statusValue, statusOnChange}){
    return (
        <div className="updateArea">
            <form onSubmit={submitStatus}>
                <textarea 
                    className="updateForm"
                    rows="4"
                    value={statusValue}
                    onChange={statusOnChange}
                    placeholder = "Please enter message..."
                />
                <div>
                    <button className="btnUpdate" type="submit">Post Message</button>
                </div>
            </form>
        </div>
    )
}